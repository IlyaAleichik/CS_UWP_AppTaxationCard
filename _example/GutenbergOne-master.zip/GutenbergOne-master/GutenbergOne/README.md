#GutenbergOne is a derivative of the SDK for Universal Winddows App Printing Example.

The reason for this work, is that I have been trying to get printing into my Essential Grocer program, the 15th try is the charm :-)

In any event, it takes some of the example wholesale and puts it in the work.  The trick is that I use a fixed width font, Courier New, so that I can programatically calculate the spaces to create a 2 column grocery list.

For some stuff this is helpful, especially if you are doing something that can be accomplished with a RichTextBox

Of note, I have no affiliation with Microsoft, other than being a vendor in the Windows App Store.  Anything that comes from Microsoft, is from their tutorial, so should be ok.
