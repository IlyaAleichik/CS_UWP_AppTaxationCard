# Manipulation_Drawing
Sample to go with a 5 part blog series on mapping
