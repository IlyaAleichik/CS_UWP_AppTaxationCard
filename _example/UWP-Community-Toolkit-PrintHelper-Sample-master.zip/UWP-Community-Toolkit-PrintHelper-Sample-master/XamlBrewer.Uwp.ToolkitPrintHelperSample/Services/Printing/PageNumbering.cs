﻿namespace Mvvm.Services
{
    public enum PageNumbering
    {
        None,
        TopLeft,
        TopMiddle,
        TopRight,
        BottomLeft,
        BottomMidle,
        BottomRight
    }
}
