﻿using Windows.UI.Xaml.Controls;

namespace XamlBrewer.Uwp.ToolkitPrintHelperSample
{
    public sealed partial class AboutPage : Page
    {
        public AboutPage()
        {
            this.InitializeComponent();
        }
    }
}
