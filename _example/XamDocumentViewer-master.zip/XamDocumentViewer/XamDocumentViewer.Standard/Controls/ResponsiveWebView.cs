﻿using Xamarin.Forms;

namespace XamDocumentViewer.Standard.Controls
{
	public class ResponsiveWebView : WebView
    {
		public ResponsiveWebView() : base() { }
    }
}
