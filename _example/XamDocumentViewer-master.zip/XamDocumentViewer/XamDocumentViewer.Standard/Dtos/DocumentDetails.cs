﻿using System.IO;

namespace XamDocumentViewer.Standard.Dtos
{
	public class DocumentDetails
	{
		public Stream Stream { get; set; }

		public string Type { get; set; }
	}
}
