﻿namespace XamDocumentViewer.Standard.Enums
{
	public enum DocumentType
    {
		Docx,
		Doc
	}
}
