﻿using System;

namespace CampusNet
{
    public class Network
    {
        public string Ssid { get; set; }
    }
}
